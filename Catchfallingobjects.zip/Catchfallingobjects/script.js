const gameContainer = document.getElementById('game-container');
const basket = document.getElementById('basket');
const scoreBoard = document.getElementById('score');
const gameOverPopup = document.getElementById('game-over-popup');
const finalScoreElement = document.getElementById('final-score');
const highestScoreElement = document.getElementById('highest-score');
const restartButton = document.getElementById('restart-button');

let basketWidth = 80;
let gameContainerWidth;
let gameContainerHeight;
let score = 0;
let highestScore = 0;
let gameInterval;
let fallingInterval;
let gameOver = false;

window.addEventListener('resize', updateDimensions);
document.addEventListener('keydown', moveBasket);
gameContainer.addEventListener('touchstart', moveBasketTouchStart);
gameContainer.addEventListener('touchmove', moveBasketTouchMove);
restartButton.addEventListener('click', restartGame);

function updateDimensions() {
    gameContainerWidth = gameContainer.offsetWidth;
    gameContainerHeight = gameContainer.offsetHeight;
    basketWidth = basket.offsetWidth;
}

function moveBasket(e) {
    const basketLeft = parseInt(window.getComputedStyle(basket).getPropertyValue('left'));
    if (e.key === 'ArrowLeft' && basketLeft > 0) {
        basket.style.left = basketLeft - 20 + 'px';
    }
    if (e.key === 'ArrowRight' && basketLeft < (gameContainerWidth - basketWidth)) {
        basket.style.left = basketLeft + 20 + 'px';
    }
}

function moveBasketTouchStart(e) {
    e.preventDefault();
    moveBasketTouchMove(e);
}

function moveBasketTouchMove(e) {
    e.preventDefault();
    const touch = e.touches[0];
    const touchX = touch.clientX - gameContainer.getBoundingClientRect().left;
    const basketLeft = touchX - basketWidth / 2;

    if (basketLeft >= 0 && basketLeft <= gameContainerWidth - basketWidth) {
        basket.style.left = basketLeft + 'px';
    }
}

function createFallingObject() {
    const fallingObject = document.createElement('div');
    fallingObject.classList.add('falling-object');
    fallingObject.style.left = Math.random() * (gameContainerWidth - 40) + 'px';
    fallingObject.style.top = '0px';
    gameContainer.appendChild(fallingObject);

    fallingInterval = setInterval(() => {
        let fallingObjectTop = parseInt(window.getComputedStyle(fallingObject).getPropertyValue('top'));
        if (fallingObjectTop >= gameContainerHeight - 40) {
            clearInterval(fallingInterval);
            gameContainer.removeChild(fallingObject);
            endGame();
        } else {
            fallingObject.style.top = fallingObjectTop + 5 + 'px';
        }

        const basketTop = parseInt(window.getComputedStyle(basket).getPropertyValue('top'));
        const basketLeft = parseInt(window.getComputedStyle(basket).getPropertyValue('left'));
        const basketRight = basketLeft + basketWidth;

        const fallingObjectLeft = parseInt(fallingObject.style.left);
        const fallingObjectRight = fallingObjectLeft + 40;

        if (fallingObjectTop >= basketTop - 40 && fallingObjectLeft >= basketLeft && fallingObjectRight <= basketRight) {
            clearInterval(fallingInterval);
            gameContainer.removeChild(fallingObject);
            score++;
            scoreBoard.textContent = score;
        }
    }, 20);
}

function startGame() {
    score = 0;
    gameOver = false;
    scoreBoard.textContent = score;
    gameOverPopup.classList.add('hidden');

    gameInterval = setInterval(createFallingObject, 1000);
}

function endGame() {
    gameOver = true;
    clearInterval(gameInterval);
    clearInterval(fallingInterval);
    finalScoreElement.textContent = score;
    if (score > highestScore) {
        highestScore = score;
        highestScoreElement.textContent = highestScore + ' (New High Score!)';
    } else {
        highestScoreElement.textContent = highestScore;
    }
    gameOverPopup.classList.remove('hidden');
}

function restartGame() {
    const fallingObjects = document.querySelectorAll('.falling-object');
    fallingObjects.forEach(object => gameContainer.removeChild(object));
    startGame();
}

updateDimensions();
startGame();
